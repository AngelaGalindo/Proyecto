package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlanesDeViajeApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlanesDeViajeApplication.class, args);
	}

}
